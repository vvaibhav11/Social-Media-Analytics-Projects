
# Setup
#!/usr/bin/python3.7
#pip3.7 install --user google-cloud
#pip3.7 install --user google-cloud-vision

import xlrd
xlrd.xlsx.ensure_elementtree_imported(False, None)
xlrd.xlsx.Element_has_iter = True

from google.cloud import vision
import os
import pandas as pd

import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
nltk.download('stopwords')
from sklearn.feature_extraction.text import CountVectorizer
from textblob import TextBlob
import itertools
from collections import Counter
import statistics as st
import numpy as np
import collections
import glob
from textblob.exceptions import NotTranslated 
from wordcloud import WordCloud
import re  
import matplotlib.pyplot as plt
from sklearn.decomposition import LatentDirichletAllocation

Application_Credentials = '**Provide yours**'
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = Application_Credentials
client = vision.ImageAnnotatorClient()
image = vision.Image()

# Give the location of the file
loc = ("C:/Users/vvaib/OneDrive/Desktop/McGill MMA/MMA 2021/WInter semester/INSY_670_social/individual_assignment/insta_download.xlsx")
 
# To open Workbook
wb = xlrd.open_workbook(loc)
sheet = wb.sheet_by_index(0)
sheet.cell_value(1, 2)
df = pd.DataFrame()

# loop through every url, retrieve the image and send to google vision
for i in range(sheet.nrows - 1):
    image_src_temp = sheet.cell_value(i+1, 2)
    comments = sheet.cell_value(i+1, 1)
    image.source.image_uri = image_src_temp
    response = client.label_detection(image=image)
    labels = response.label_annotations
    l = []
    for label in labels:
        l.append(label.description)
    s = ' '.join(l)
    print("s")
    print(s)
    df = df.append({'URL': image_src_temp, 'Labels': s, 'comments': comments}, ignore_index=True)

#df.to_excel("GV_Output.xlsx",index=False)

################### Label cleaning before topic modeling ######################

# Stopwords removal
df['Labels'] = df['Labels'].astype('str')
df['Labels']= df["Labels"].str.lower()

english_stop_words = stopwords.words('english')

df['Labels'] = df['Labels'].apply(lambda x: ' '.join([word for word in x.split() if word not in (english_stop_words)]))

# Limmization

def get_lemmatized_text(corpus):
    from nltk.stem import WordNetLemmatizer
    lemmatizer = WordNetLemmatizer()
    return [' '.join([lemmatizer.lemmatize(word) for word in review.split()]) for review in corpus]

df['Labels'] = get_lemmatized_text(df['Labels'])
df['Labels'] = df['Labels'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

# Tokenize lemmatized comments

def apwords(words):
    tokenize = []
    words = nltk.pos_tag(word_tokenize(words))
    for w in words:
        tokenize.append(w)
    return tokenize

addwords = lambda x: apwords(x)

df['Labels'] = df['Labels'].apply(addwords)

# removing unwarrented tags

c1 = df['Labels'].tolist()

final_tags = [ [] for i in range(len(df['Labels'])) ]

tags = ['FW','JJ','JJR','JJS','MD','NN','NNS','NNP','NNPS','RB','RBR','RBS',
        'SYM','VB','VBD','VBG','VBN']

for i in range(len(c1)):
    #print(i)
    for j in range(len(c1[i])):
        #print(j)
        for k in tags:
            if k == c1[i][j][1]:
                final_tags[i].append(c1[i][j][0])
                continue

df['Labels'] = final_tags

# word frequency
c2 = list(itertools.chain.from_iterable(df['Labels']))

counts = Counter(c2)
data_items = counts.items()
data_list = list(data_items)

word_frequency = pd.DataFrame(data_list)
word_frequency.rename(columns = {0:'word', 1:'frequency'}, inplace = True)
word_frequency = word_frequency.sort_values(by = 'frequency', ascending = False)

# word cloud

word_frequency = word_frequency[word_frequency["word"].str.contains("war|amp|chapter|let|brk|big") == False]
data = word_frequency.set_index('word').to_dict()['frequency']
wc = WordCloud(width=800, height=400, max_words=200).generate_from_frequencies(data)
plt.figure(figsize=(10, 10))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')
plt.show()

################### LDA topic modeling on all label of images (method 1) #####################
df['Labels2'] = [' '.join(map(str, l)) for l in df['Labels']]

# the vectorizer object will be used to transform text to vector form
vectorizer = CountVectorizer(max_df=0.9, min_df=25, token_pattern='\w+|\$[\d\.]+|\S+')

# apply transformation
tf = vectorizer.fit_transform(df['Labels2']).toarray()

# tf_feature_names tells us what word each column in the matric represents
tf_feature_names = vectorizer.get_feature_names()

number_of_topics = 6

model = LatentDirichletAllocation(n_components=number_of_topics, random_state=0)

model.fit(tf)

def display_topics(model, feature_names, no_top_words):
    topic_dict = {}
    for topic_idx, topic in enumerate(model.components_):
        topic_dict["Topic %d words" % (topic_idx)]= ['{}'.format(feature_names[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
        topic_dict["Topic %d weights" % (topic_idx)]= ['{:.1f}'.format(topic[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
    return pd.DataFrame(topic_dict)

no_top_words = 25
tm = pd.DataFrame(display_topics(model, tf_feature_names, no_top_words))

######## LDA topic modeling on highest and lowest quartile of labels of images #######

# Creating quartile
df['QuantileRank']= pd.qcut(df['comments'],
                             q = 4, labels = False)

# Creating Decile Rank
df['DecileRank']= pd.qcut(df['comments'],
                           q = 4, labels = False)

############################### LDA topic modeling on high quartile label of images ##################################
df2 = df[(df['QuantileRank'] == 3) | (df['QuantileRank'] == 2)]

df2['Labels2'] = [' '.join(map(str, l)) for l in df2['Labels']]

# the vectorizer object will be used to transform text to vector form
vectorizer = CountVectorizer(max_df=0.9, min_df=25, token_pattern='\w+|\$[\d\.]+|\S+')

# apply transformation
tf = vectorizer.fit_transform(df2['Labels2']).toarray()

# tf_feature_names tells us what word each column in the matric represents
tf_feature_names = vectorizer.get_feature_names()

number_of_topics = 6

model = LatentDirichletAllocation(n_components=number_of_topics, random_state=0)

model.fit(tf)

def display_topics(model, feature_names, no_top_words):
    topic_dict = {}
    for topic_idx, topic in enumerate(model.components_):
        topic_dict["Topic %d words" % (topic_idx)]= ['{}'.format(feature_names[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
        topic_dict["Topic %d weights" % (topic_idx)]= ['{:.1f}'.format(topic[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
    return pd.DataFrame(topic_dict)

no_top_words = 25
tm2 = pd.DataFrame(display_topics(model, tf_feature_names, no_top_words))

################################### LDA topic modeling on low quartile label of images ################################
df3 = df[(df['QuantileRank'] == 0) | (df['QuantileRank'] == 1)]

df3['Labels2'] = [' '.join(map(str, l)) for l in df3['Labels']]

# the vectorizer object will be used to transform text to vector form
vectorizer = CountVectorizer(max_df=0.9, min_df=25, token_pattern='\w+|\$[\d\.]+|\S+')

# apply transformation
tf = vectorizer.fit_transform(df3['Labels2']).toarray()

# tf_feature_names tells us what word each column in the matric represents
tf_feature_names = vectorizer.get_feature_names()

number_of_topics = 6

model = LatentDirichletAllocation(n_components=number_of_topics, random_state=0)

model.fit(tf)

def display_topics(model, feature_names, no_top_words):
    topic_dict = {}
    for topic_idx, topic in enumerate(model.components_):
        topic_dict["Topic %d words" % (topic_idx)]= ['{}'.format(feature_names[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
        topic_dict["Topic %d weights" % (topic_idx)]= ['{:.1f}'.format(topic[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
    return pd.DataFrame(topic_dict)

no_top_words = 25
tm3 = pd.DataFrame(display_topics(model, tf_feature_names, no_top_words))

#######################################################################################
##################### Finding optimal number of topics in LDA #########################
# Gensim
import gensim
import gensim.corpora as corpora
from gensim.utils import simple_preprocess
from gensim.models import CoherenceModel
from gensim.models import wrappers

import os
from gensim.models.wrappers import LdaMallet

# Plotting tools
import pyLDAvis
import pyLDAvis.gensim  # don't skip this
import matplotlib.pyplot as plt

# Create Dictionary
id2word = corpora.Dictionary(df['Labels'])

# Create Corpus
texts = df['Labels']

# Term Document Frequency
corpus = [id2word.doc2bow(text) for text in texts]

# View
print(corpus[:1])

#id2word[0]

# Human readable format of corpus (term-frequency)
[[(id2word[id], freq) for id, freq in cp] for cp in corpus[:1]]

# Build LDA model
lda_model = gensim.models.ldamodel.LdaModel(corpus=corpus,
                                           id2word=id2word,
                                           num_topics=20, 
                                           random_state=100,
                                           update_every=1,
                                           chunksize=100,
                                           passes=10,
                                           alpha='auto',
                                           per_word_topics=True)

# Print the Keyword in the 10 topics
print(lda_model.print_topics())
doc_lda = lda_model[corpus]

# Compute Perplexity
print('\nPerplexity: ', lda_model.log_perplexity(corpus))  # a measure of how good the model is. lower the better.

# Compute Coherence Score
coherence_model_lda = CoherenceModel(model=lda_model, texts=df['Labels'], dictionary=id2word, coherence='c_v')
coherence_lda = coherence_model_lda.get_coherence()
print('\nCoherence Score: ', coherence_lda)

# Visualize the topics
pyLDAvis.enable_notebook()
vis = pyLDAvis.gensim.prepare(lda_model, corpus, id2word)
vis

# Download File: http://mallet.cs.umass.edu/dist/mallet-2.0.8.zip

os.environ['MALLET_HOME'] = 'C:/Users/vvaib/Downloads/mallet-2.0.8'
mallet_path = 'C:/Users/vvaib/Downloads/mallet-2.0.8/bin/mallet'
ldamallet = gensim.models.wrappers.LdaMallet(mallet_path, corpus=corpus, num_topics=20, id2word=id2word)

def compute_coherence_values(dictionary, corpus, texts, limit, start=2, step=3):
    """
    Compute c_v coherence for various number of topics

    Parameters:
    ----------
    dictionary : Gensim dictionary
    corpus : Gensim corpus
    texts : List of input texts
    limit : Max num of topics

    Returns:
    -------
    model_list : List of LDA topic models
    coherence_values : Coherence values corresponding to the LDA model with respective number of topics
    """
    coherence_values = []
    model_list = []
    for num_topics in range(start, limit, step):
        model = gensim.models.wrappers.LdaMallet(mallet_path, corpus=corpus, num_topics=num_topics, id2word=id2word)
        model_list.append(model)
        coherencemodel = CoherenceModel(model=model, texts=texts, dictionary=dictionary, coherence='c_v')
        coherence_values.append(coherencemodel.get_coherence())

    return model_list, coherence_values

# Can take a long time to run.
model_list, coherence_values = compute_coherence_values(dictionary=id2word, corpus=corpus, texts=df['Labels'], start=2, limit=40, step=6)

# Show graph
limit=40; start=2; step=6;
x = range(start, limit, step)
plt.plot(x, coherence_values)
plt.xlabel("Num Topics")
plt.ylabel("Coherence score")
plt.legend(("coherence_values"), loc='best')
plt.show()
