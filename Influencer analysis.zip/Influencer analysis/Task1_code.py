# -*- coding: utf-8 -*-
"""
Created on Sun Mar 20 14:10:56 2022

@author: vvaib
"""
#################### Setup ######################
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import time

# Models
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC 
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from xgboost import XGBClassifier
from catboost import CatBoostClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Evaluation metrics
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score

################################# Alternate 1 (A-B) ####################################
####################### data load and initial analysis/cleaning ########################
df = pd.read_csv("train.csv")

df.head()
df.tail()
df.describe()
pd.isnull(df)

df = df.dropna()

# Transforming data for modeling
df['com_follower_count'] = df.A_follower_count -  df.B_follower_count
df['com_following_count'] = df.A_following_count -  df.B_following_count
df['com_listed_count'] = df.A_listed_count -  df.B_listed_count
df['com_mentions_recieved'] = df.A_mentions_received-df.B_mentions_received
df['com_retweets_recieved'] = df.A_retweets_received -df.B_retweets_received
df['com_mentions_sent'] = df.A_mentions_sent - df.B_mentions_sent
df['com_retweets_sent'] = df.A_retweets_sent -  df.B_retweets_sent
df['com_posts'] = df.A_posts -  df.B_posts
df['com_network_feature_1'] = df.A_network_feature_1 - df.B_network_feature_1
df['com_network_feature_2'] = df.A_network_feature_2 - df.B_network_feature_2
df['com_network_feature_3'] = df.A_network_feature_3 - df.B_network_feature_3

####################### Model Building and accuracy ckecks ########################
# train and test split
X = df.iloc[:, 1:]
y = df.Choice

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20 ,random_state=42)
X_train2 = X_train.iloc[:,:21]
X_test2 = X_test.iloc[:,:21]
X_train = X_train.iloc[:,22:]
X_test = X_test.iloc[:,22:]

# Standardization
#scaler = StandardScaler()
#X_train = scaler.fit_transform(X_train)
#X_test = scaler.transform(X_test)

# Initilizing the dataframe for storing model results
exploration_results = pd.DataFrame(columns=['Model', 'accuracy:', 'precision:', 'recall:', 'F1 Score', 'Fitting Time'])

# Function to run model without feature importance (non tree/ boosting algorithms)
def fitAndLog(classifier, resultsDF, X_train, X_test, y_train, y_test):
    start_time = time.time()
    classifier.fit(X_train, y_train)
    y_pred_temp = classifier.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred_temp)
    precision = precision_score(y_test, y_pred_temp)
    recall = recall_score(y_test, y_pred_temp)
    f1 = f1_score(y_test, y_pred_temp)
    end_time = time.time()
    # confusion matrix
    data = confusion_matrix(y_test, y_pred_temp)
    df_cm = pd.DataFrame(data, columns=np.unique(y_test), index = np.unique(y_test))
    df_cm.index.name = 'Actual'
    df_cm.columns.name = 'Predicted'
    plt.figure(figsize = (10,7))
    sns.set(font_scale=1.4)
    sns.heatmap(df_cm, cmap="Blues", annot=True, annot_kws={"size": 16}, fmt='g').set_title(classifier)
    resultsDF = resultsDF.append(pd.Series([classifier, accuracy, precision, recall, f1, format(end_time-start_time)], index=resultsDF.columns), ignore_index=True)
    return resultsDF

# Function to run model with feature importance function (tree and boosting algorithms)
def fitAndLog2(classifier, resultsDF, X_train, X_test, y_train, y_test):
    start_time = time.time()
    classifier.fit(X_train, y_train)
    y_pred_temp = classifier.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred_temp)
    precision = precision_score(y_test, y_pred_temp)
    recall = recall_score(y_test, y_pred_temp)
    f1 = f1_score(y_test, y_pred_temp)
    end_time = time.time()
    # confusion matrix
    data = confusion_matrix(y_test, y_pred_temp)
    df_cm = pd.DataFrame(data, columns=np.unique(y_test), index = np.unique(y_test))
    df_cm.index.name = 'Actual'
    df_cm.columns.name = 'Predicted'
    plt.figure(figsize = (10,7))
    sns.set(font_scale=1.4)
    sns.heatmap(df_cm, cmap="Blues", annot=True, annot_kws={"size": 16}, fmt='g').set_title(classifier)
    # feature importance
    n_features = X_train.shape[1]
    importances = classifier.feature_importances_
    indices = np.argsort(importances)
    plt.figure(figsize=(20,20))
    plt.barh(range(n_features),importances[indices], align='center') 
    plt.yticks(np.arange(n_features), X_train.columns.values) 
    plt.xlabel('Feature importance')
    plt.ylabel('Feature')
    plt.title(classifier)
    resultsDF = resultsDF.append(pd.Series([classifier, accuracy, precision, recall, f1, format(end_time-start_time)], index=resultsDF.columns), ignore_index=True)
    return resultsDF


# Calling function for different classifiaction algorithms
'''1. Logistic Regression
   2. Decision Tree
   3. Random Forest
   4. Support vector machine
   5. Naive Bayes
   6. Gradient Boosting
   7. MLP Classifier
   7. XGBoost
   8. CatBoost
   10. KNN
   11. SGD
'''

# LogisticRegression
lr = LogisticRegression()
exploration_results = fitAndLog(lr, exploration_results, X_train, X_test, y_train, y_test)
exploration_results

# DecisionTreeClassifier
dt = DecisionTreeClassifier()
exploration_results = fitAndLog2(dt, exploration_results, X_train, X_test, y_train, y_test)
exploration_results

# RandomForestClassifier
rf = RandomForestClassifier()
exploration_results = fitAndLog2(rf, exploration_results, X_train, X_test, y_train, y_test)
exploration_results

# svm
#svm = SVC(kernel='linear') 
#exploration_results = fitAndLog(svm, exploration_results, X_train, X_test, y_train, y_test)
#exploration_results

# Naive Bayes (GaussianNB)
nb = GaussianNB()
exploration_results = fitAndLog(nb, exploration_results, X_train, X_test, y_train, y_test)
exploration_results

# GradientBoostingClassifier
gbc = GradientBoostingClassifier()
exploration_results = fitAndLog2(gbc, exploration_results, X_train, X_test, y_train, y_test)
exploration_results

# MLPClassifier
mlp = MLPClassifier()
exploration_results = fitAndLog(mlp, exploration_results, X_train, X_test, y_train, y_test)
exploration_results

# XGBClassifier
xgb = XGBClassifier()
exploration_results = fitAndLog2(xgb, exploration_results, X_train, X_test, y_train, y_test)
exploration_results

# CatBoostClassifier
catboost = CatBoostClassifier()
exploration_results = fitAndLog2(catboost, exploration_results, X_train, X_test, y_train, y_test)
exploration_results

# KNeighborsClassifier
knn = KNeighborsClassifier()
exploration_results = fitAndLog(knn, exploration_results, X_train, X_test, y_train, y_test)
exploration_results

# SGDClassifier
sgdc = SGDClassifier()
exploration_results = fitAndLog(sgdc, exploration_results, X_train, X_test, y_train, y_test)
exploration_results

''' Financial value of the model '''
''' Ans:
A retailer wants influencers to tweet its promotion for a product.

If a non-influencer tweets, there is no benefit to the retailer.
If an influencer tweets once, there is a 0.02% chance that his/her followers will buy one unit of a product.

Assume the retailer has a profit margin of $10 per unit, and that one customer can buy only one unit. 

If an influencer tweets twice, the overall buying probability will be 0.03%. 

Without analytics, the retailer offers $5 to each person (A and B) to tweet once. 

With analytics, the retailer offers $10 to those identified as influencers by the model to send two tweets each. 
If the model classifies an individual as a non-influencer, s/he is not selected/paid by the 
retailer to tweet

What is the boost in expected net profit from using your analytic model (versus not using analytics)? Show all calculations.

Ans: all influencers identified in test set to be influencers by our model get 10 dollars to tweet twice those of them who are actually influencers incur a profit of 0.03/100 * follower_count. The rest are a waste of revenue. 


What is the boost in net profit from using a perfect analytic model (versus not using analytics)?

Just use test set with perfect prediction of who is influencer this is easy to calculate use a subset of test data with only influencers multiply 0.03/100* follower count for each and sum 

*Assumption: Each user appears only once in the data'''

y1 = pd.DataFrame(y_test)
df_test = pd.concat([pd.DataFrame(X_test2), y1], axis=1)

#Without analytics on test data
influ_A = df_test.loc[df_test['Choice'] == 1]
influ_B = df_test.loc[df_test['Choice'] == 0]

count_A = influ_A['A_follower_count'].count()
count_B = influ_B['B_follower_count'].count()

tot_fol_A = influ_A['A_follower_count'].sum()
tot_fol_B = influ_B['B_follower_count'].sum()

low_profit  = (tot_fol_A*0.0002*10) - (count_A*10) + (tot_fol_B*0.0002*10) - (count_B*10)

print('with-out analytics profit:$',round(low_profit))

# Run best model from model stats separately to generate test predictions
gbc = GradientBoostingClassifier()
gbc.fit(X_train, y_train)
y_pred_temp = gbc.predict(X_test)

y2 = []
y2 = y_pred_temp.tolist()
df_test['test_Choice'] = y2

#with analytics on test data
pot_influencers = len(df_test)

influ_A = df_test[((df_test['Choice'] == 1) & (df_test['test_Choice'] == 1))]
influ_B = df_test[((df_test['Choice'] == 0) & (df_test['test_Choice'] == 0))]

count_A = influ_A['A_follower_count'].count()
count_B = influ_B['B_follower_count'].count()

tot_fol_A = influ_A['A_follower_count'].sum()
tot_fol_B = influ_B['B_follower_count'].sum()

Analytics_profit  = (tot_fol_A*0.0003*10) + (tot_fol_B*0.0003*10) - (pot_influencers*10)

print('with analytics profit:$', round(Analytics_profit))
print("Boost from using analytics:$", round(Analytics_profit-low_profit) )

#Perfect profit for test set
influ_A = df_test.loc[df_test['Choice'] == 1]
influ_B = df_test.loc[df_test['Choice'] == 0]

count_A = influ_A['A_follower_count'].count()
count_B = influ_B['B_follower_count'].count()

tot_fol_A = influ_A['A_follower_count'].sum()
tot_fol_B = influ_B['B_follower_count'].sum()

perf_profit  = (tot_fol_A*0.0003*10) - (count_A*10) + (tot_fol_B*0.0003*10) - (count_B*10)

print('perfect profit:$',round(perf_profit))
print("Boost from using Perfect analytics:$",round(perf_profit-low_profit) )















