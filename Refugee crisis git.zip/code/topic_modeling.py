# -*- coding: utf-8 -*-
"""
Created on Sat Apr  9 03:40:33 2022

@author: vvaib
"""
''' Content of Code
1. Setup 
2. Dat load and pre processing
3. Stop words, Lemmatization , tokenization
4. Word frequency, wordcloud
5. Bar plot on locations of tweets
6. Topic modeling '''

########################## Setup/required packages ######################################################
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
import pandas as pd
nltk.download('stopwords')
from sklearn.feature_extraction.text import CountVectorizer
from textblob import TextBlob
import itertools
from collections import Counter
import statistics as st
import numpy as np
import collections
import os
import glob
from googletrans import Translator
from textblob.exceptions import NotTranslated 
from wordcloud import WordCloud
import re  
import matplotlib.pyplot as plt
from sklearn.decomposition import LatentDirichletAllocation

translator = Translator()

###################### Loading data files ########################
# Syria war
sw = pd.read_csv("tweets_keyword_#War_Syria_processed.csv")
sw2 = pd.read_csv("tweets_keyword_#War #Syria_processed.csv")
syria_war = sw.append(sw2, ignore_index=True)
syria_war = syria_war.head(5000)

#Replacing nan with '' & removing special character/ punctuations & single character word
syria_war['Content'] = syria_war['Content'].replace(np.nan, '')
syria_war['Content'] = syria_war['Content'].str.replace('[^\w\s]', '')
syria_war['Content'] = syria_war['Content'].map(lambda x: re.sub('[,\.!?]', '', x))
syria_war['Content'] = syria_war['Content'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

syria_war['Location'] = syria_war['Location'].replace(np.nan, '')
syria_war['Location'] = syria_war['Location'].str.replace('[^\w\s]', '')
syria_war['Location'] = syria_war['Location'].map(lambda x: re.sub('[,\.!?]', '', x))
syria_war['Location'] = syria_war['Location'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

# Ukraine war
uw = pd.read_csv("tweets_keyword_#War #Ukraine_processed.csv")
uw2 = pd.read_csv("tweets_keyword_#War_Ukraine_processed.csv")
ukraine_war = uw.append(uw2, ignore_index=True)
ukraine_war = ukraine_war.head(5000)

#Replacing nan with '' & removing special character/ punctuations & single character word
ukraine_war['Content'] = ukraine_war['Content'].replace(np.nan, '')
ukraine_war['Content'] = ukraine_war['Content'].str.replace('[^\w\s]', '')
ukraine_war['Content'] = ukraine_war['Content'].map(lambda x: re.sub('[,\.!?]', '', x))
ukraine_war['Content'] = ukraine_war['Content'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

ukraine_war['Location'] = ukraine_war['Location'].replace(np.nan, '')
ukraine_war['Location'] = ukraine_war['Location'].str.replace('[^\w\s]', '')
ukraine_war['Location'] = ukraine_war['Location'].map(lambda x: re.sub('[,\.!?]', '', x))
ukraine_war['Location'] = ukraine_war['Location'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

# Syria refugee
sr = pd.read_csv("tweets_keyword_#Refugees #Syria_processed.csv")
sr2 = pd.read_csv("tweets_keyword_#Refugees_Syria#1_processed.csv")
sr3 = pd.read_csv("tweets_keyword_#Refugees_Syria#2_processed.csv")
syria_ref = sr.append([sr2, sr3], ignore_index=True)
syria_ref = syria_ref.head(5000)

#Replacing nan with '' & removing special character/ punctuations & single character word
syria_ref['Content'] = syria_ref['Content'].replace(np.nan, '')
syria_ref['Content'] = syria_ref['Content'].str.replace('[^\w\s]', '')
syria_ref['Content'] = syria_ref['Content'].map(lambda x: re.sub('[,\.!?]', '', x))
syria_ref['Content'] = syria_ref['Content'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

syria_ref['Location'] = syria_ref['Location'].replace(np.nan, '')
syria_ref['Location'] = syria_ref['Location'].str.replace('[^\w\s]', '')
syria_ref['Location'] = syria_ref['Location'].map(lambda x: re.sub('[,\.!?]', '', x))
syria_ref['Location'] = syria_ref['Location'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

# Ukraine refugee
ur = pd.read_csv("tweets_keyword_#Refugees #Ukraine_processed.csv")
ur2 = pd.read_csv("tweets_keyword_#Refugees_Ukraine_processed.csv")
ukraine_ref = uw.append(uw2, ignore_index=True)
ukraine_ref = ukraine_ref.head(5000)

#Replacing nan with '' & removing special character/ punctuations & single character word
ukraine_ref['Content'] = ukraine_ref['Content'].replace(np.nan, '')
ukraine_ref['Content'] = ukraine_ref['Content'].str.replace('[^\w\s]', '')
ukraine_ref['Content'] = ukraine_ref['Content'].map(lambda x: re.sub('[,\.!?]', '', x))
ukraine_ref['Content'] = ukraine_ref['Content'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

ukraine_ref['Location'] = ukraine_ref['Location'].replace(np.nan, '')
ukraine_ref['Location'] = ukraine_ref['Location'].str.replace('[^\w\s]', '')
ukraine_ref['Location'] = ukraine_ref['Location'].map(lambda x: re.sub('[,\.!?]', '', x))
ukraine_ref['Location'] = ukraine_ref['Location'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

# list of cities and countries
city_country = pd.read_csv('https://datahub.io/core/world-cities/r/world-cities.csv')
city_country.rename(columns ={"name":"city"}, inplace=True)
city = city_country['city'].str.lower().tolist()

########################## translation of different languages ########################

def translate_comment(x):
    try:
        # Try to translate the string version of the comment
        return TextBlob(str(x)).translate(to='en')
    except NotTranslated:
        # If the output is the same as the input just return the TextBlob version of the input
        return TextBlob(str(x))

# Syria war tweets
syria_war['Content'] = syria_war['Content'].apply(translate_comment)
syria_war['Location'] = syria_war['Location'].apply(translate_comment)

# Ukraine war tweets
ukraine_war['Content'] = ukraine_war['Content'].apply(translate_comment)
ukraine_war['Location'] = ukraine_war['Location'].apply(translate_comment)

# Syria Refugee tweets
syria_ref['Content'] = syria_ref['Content'].apply(translate_comment)
syria_ref['Location'] = syria_ref['Location'].apply(translate_comment)

# Ukraine Refugee tweets
ukraine_ref['Content'] = ukraine_ref['Content'].apply(translate_comment)
ukraine_ref['Location'] = ukraine_ref['Location'].apply(translate_comment)

# temporary backup in case of loosing kernel as translating tweets take lot of time
t1 = syria_war
t2 = ukraine_war
t3 = syria_ref
t4 = ukraine_ref

# Writing temporary file
syria_war.to_csv('syria_war_translate.csv', sep=',')
ukraine_war.to_csv('ukraine_war_translate.csv', sep=',')
syria_ref.to_csv('syria_ref_translate.csv', sep=',')
ukraine_ref.to_csv('ukraine_ref_translate.csv', sep=',')


################ delete at end #########################
syria_war = pd.read_csv("syria_war_translate.csv")
ukraine_war = pd.read_csv("ukraine_war_translate.csv")
syria_ref = pd.read_csv("syria_ref_translate.csv")
ukraine_ref = pd.read_csv("ukraine_ref_translate.csv")


###############################################################################
##################################### Syria war ###############################
# stop word removal

syria_war['Content'] = syria_war['Content'].astype('str')
syria_war['Location'] = syria_war['Location'].astype('str')

syria_war['clean_content']= syria_war["Content"].str.lower()
syria_war['clean_locs']= syria_war["Location"].str.lower()

english_stop_words = stopwords.words('english')

syria_war['clean_content'] = syria_war['clean_content'].apply(lambda x: ' '.join([word for word in x.split() if word not in (english_stop_words)]))
syria_war['clean_locs'] = syria_war['clean_locs'].apply(lambda x: ' '.join([word for word in x.split() if word not in (english_stop_words)]))

################################# Limmization ##########################################

def get_lemmatized_text(corpus):
    from nltk.stem import WordNetLemmatizer
    lemmatizer = WordNetLemmatizer()
    return [' '.join([lemmatizer.lemmatize(word) for word in review.split()]) for review in corpus]

syria_war['clean_content'] = get_lemmatized_text(syria_war['clean_content'])
syria_war['clean_content'] = syria_war['clean_content'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

syria_war['clean_locs'] = get_lemmatized_text(syria_war['clean_locs'])
syria_war['clean_locs'] = syria_war['clean_locs'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

############################## Tokenize lemmatized comments ############################

def apwords(words):
    tokenize = []
    words = nltk.pos_tag(word_tokenize(words))
    for w in words:
        tokenize.append(w)
    return tokenize

addwords = lambda x: apwords(x)

syria_war['clean_content'] = syria_war['clean_content'].apply(addwords)
syria_war['clean_locs'] = syria_war['clean_locs'].apply(addwords)

#################### removing unwarrented tags ########################################

c1 = syria_war['clean_content'].tolist()

final_tags = [ [] for i in range(5000) ]

tags = ['FW','JJ','JJR','JJS','MD','NN','NNS','NNP','NNPS','RB','RBR','RBS',
        'SYM','VB','VBD','VBG','VBN']

for i in range(len(c1)):
    #print(i)
    for j in range(len(c1[i])):
        #print(j)
        for k in tags:
            if k == c1[i][j][1]:
                final_tags[i].append(c1[i][j][0])
                continue

syria_war['clean_content'] = final_tags

#
c2 = syria_war['clean_locs'].tolist()

final_tags2 = [ [] for i in range(5000) ]

for i in range(len(c2)):
    #print(i)
    for j in range(len(c2[i])):
        #print(j)
        for k in tags:
            if k == c2[i][j][1]:
                final_tags2[i].append(c2[i][j][0])
                continue

syria_war['clean_locs'] = final_tags2

################### word frequency on Syria refugee tweets & location #####################
c3 = list(itertools.chain.from_iterable(syria_war['clean_content']))

counts = Counter(c3)
data_items = counts.items()
data_list = list(data_items)

word_frequency = pd.DataFrame(data_list)
word_frequency.rename(columns = {0:'word', 1:'frequency'}, inplace = True)
word_frequency = word_frequency.sort_values(by = 'frequency', ascending = False)

c4 = list(itertools.chain.from_iterable(syria_war['clean_locs']))

counts = Counter(c4)
data_items = counts.items()
data_list = list(data_items)

word_frequency2 = pd.DataFrame(data_list)
word_frequency2.rename(columns = {0:'word', 1:'frequency'}, inplace = True)
word_frequency2 = word_frequency2.sort_values(by = 'frequency', ascending = False)

#syria_war = syria_war[syria_war['clean_locs'].isin(city)]

#################### Word cloud on Syria war tweets #####################

word_frequency = word_frequency[word_frequency["word"].str.contains("war|amp|chapter|let|brk|big") == False]
data = word_frequency.set_index('word').to_dict()['frequency']
wc = WordCloud(width=800, height=400, max_words=200).generate_from_frequencies(data)
plt.figure(figsize=(10, 10))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')
plt.show()

word_frequency2 = word_frequency2[word_frequency2["word"].str.contains("new|book") == False]
data2 = word_frequency2.set_index('word').to_dict()['frequency']
wc = WordCloud(width=800, height=400, max_words=200).generate_from_frequencies(data2)
plt.figure(figsize=(10, 10))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')
plt.show()

#################################################################################
#################################################################################
################################### Ukraine war #################################
# stop word removal
ukraine_war['Content'] = ukraine_war['Content'].astype('str')
ukraine_war['Location'] = ukraine_war['Location'].astype('str')

ukraine_war['clean_content']= ukraine_war["Content"].str.lower()
ukraine_war['clean_locs']= ukraine_war["Location"].str.lower()

ukraine_war['clean_content'] = ukraine_war['clean_content'].apply(lambda x: ' '.join([word for word in x.split() if word not in (english_stop_words)]))
ukraine_war['clean_locs'] = ukraine_war['clean_locs'].apply(lambda x: ' '.join([word for word in x.split() if word not in (english_stop_words)]))

################################# Limmization ##########################################

ukraine_war['clean_content'] = get_lemmatized_text(ukraine_war['clean_content'])
ukraine_war['clean_content'] = ukraine_war['clean_content'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

ukraine_war['clean_locs'] = get_lemmatized_text(ukraine_war['clean_locs'])
ukraine_war['clean_locs'] = ukraine_war['clean_locs'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

############################## Tokenize lemmatized comments ############################

ukraine_war['clean_content'] = ukraine_war['clean_content'].apply(addwords)
ukraine_war['clean_locs'] = ukraine_war['clean_locs'].apply(addwords)

#################### removing unwarrented tags ########################################

c1 = ukraine_war['clean_content'].tolist()

final_tags = [ [] for i in range(5000) ]

for i in range(len(c1)):
    #print(i)
    for j in range(len(c1[i])):
        #print(j)
        for k in tags:
            if k == c1[i][j][1]:
                final_tags[i].append(c1[i][j][0])
                continue

ukraine_war['clean_content'] = final_tags

#
c2 = ukraine_war['clean_locs'].tolist()

final_tags2 = [ [] for i in range(5000) ]

for i in range(len(c2)):
    #print(i)
    for j in range(len(c2[i])):
        #print(j)
        for k in tags:
            if k == c2[i][j][1]:
                final_tags2[i].append(c2[i][j][0])
                continue

ukraine_war['clean_locs'] = final_tags2

################### word frequency on Ukraine war tweets & location #####################
c3 = list(itertools.chain.from_iterable(ukraine_war['clean_content']))

counts = Counter(c3)
data_items = counts.items()
data_list = list(data_items)

word_frequency3 = pd.DataFrame(data_list)
word_frequency3.rename(columns = {0:'word', 1:'frequency'}, inplace = True)
word_frequency3 = word_frequency3.sort_values(by = 'frequency', ascending = False)

c4 = list(itertools.chain.from_iterable(ukraine_war['clean_locs']))

counts = Counter(c4)
data_items = counts.items()
data_list = list(data_items)

word_frequency4 = pd.DataFrame(data_list)
word_frequency4.rename(columns = {0:'word', 1:'frequency'}, inplace = True)
word_frequency4 = word_frequency4.sort_values(by = 'frequency', ascending = False)

#syria_war = syria_war[syria_war['clean_locs'].isin(city)]

#################### Word cloud on Ukraine war tweets #####################
word_frequency3 = word_frequency3[word_frequency3["word"].str.contains("war|amp|people|breaking|breakingnews|news|new|day") == False]
data3 = word_frequency3.set_index('word').to_dict()['frequency']
wc = WordCloud(width=800, height=400, max_words=200).generate_from_frequencies(data3)
plt.figure(figsize=(10, 10))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')
plt.show()

word_frequency4 = word_frequency4[word_frequency4["word"].str.contains("somewhere|et|baby|city|free|way|air|good|fund|help") == False]
data4 = word_frequency4.set_index('word').to_dict()['frequency']
wc = WordCloud(width=800, height=400, max_words=200).generate_from_frequencies(data4)
plt.figure(figsize=(10, 10))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')
plt.show()

#################################################################################
#################################################################################
################################### Syria Refugee ###############################
# stop word removal
syria_ref['Content'] = syria_ref['Content'].astype('str')
syria_ref['Location'] = syria_ref['Location'].astype('str')

syria_ref['clean_content']= syria_ref["Content"].str.lower()
syria_ref['clean_locs']= syria_ref["Location"].str.lower()

syria_ref['clean_content'] = syria_ref['clean_content'].apply(lambda x: ' '.join([word for word in x.split() if word not in (english_stop_words)]))
syria_ref['clean_locs'] = syria_ref['clean_locs'].apply(lambda x: ' '.join([word for word in x.split() if word not in (english_stop_words)]))

################################# Limmization ##########################################

syria_ref['clean_content'] = get_lemmatized_text(syria_ref['clean_content'])
syria_ref['clean_content'] = syria_ref['clean_content'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

syria_ref['clean_locs'] = get_lemmatized_text(syria_ref['clean_locs'])
syria_ref['clean_locs'] = syria_ref['clean_locs'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

############################## Tokenize lemmatized comments ############################

syria_ref['clean_content'] = syria_ref['clean_content'].apply(addwords)
syria_ref['clean_locs'] = syria_ref['clean_locs'].apply(addwords)

########################## removing unwarrented tags ###################################

c1 = syria_ref['clean_content'].tolist()

final_tags = [ [] for i in range(5000) ]

tags = ['FW','JJ','JJR','JJS','MD','NN','NNS','NNP','NNPS','RB','RBR','RBS',
        'SYM','VB','VBD','VBG','VBN']

for i in range(len(c1)):
    #print(i)
    for j in range(len(c1[i])):
        #print(j)
        for k in tags:
            if k == c1[i][j][1]:
                final_tags[i].append(c1[i][j][0])
                continue

syria_ref['clean_content'] = final_tags

#
c2 = syria_ref['clean_locs'].tolist()

final_tags2 = [ [] for i in range(5000) ]

for i in range(len(c2)):
    #print(i)
    for j in range(len(c2[i])):
        #print(j)
        for k in tags:
            if k == c2[i][j][1]:
                final_tags2[i].append(c2[i][j][0])
                continue

syria_ref['clean_locs'] = final_tags2

################### word frequency on Syria refugee tweets & location #####################
c3 = list(itertools.chain.from_iterable(syria_ref['clean_content']))

counts = Counter(c3)
data_items = counts.items()
data_list = list(data_items)

word_frequency5 = pd.DataFrame(data_list)
word_frequency5.rename(columns = {0:'word', 1:'frequency'}, inplace = True)
word_frequency5 = word_frequency5.sort_values(by = 'frequency', ascending = False)

c4 = list(itertools.chain.from_iterable(syria_ref['clean_locs']))

counts = Counter(c4)
data_items = counts.items()
data_list = list(data_items)

word_frequency6 = pd.DataFrame(data_list)
word_frequency6.rename(columns = {0:'word', 1:'frequency'}, inplace = True)
word_frequency6 = word_frequency6.sort_values(by = 'frequency', ascending = False)

#syria_war = syria_war[syria_war['clean_locs'].isin(city)]

#################### Word cloud on Syria Refugee tweets #####################
word_frequency5 = word_frequency5[word_frequency5["word"].str.contains("amp|new|way|ago") == False]
data5 = word_frequency5.set_index('word').to_dict()['frequency']
wc = WordCloud(width=800, height=400, max_words=200).generate_from_frequencies(data5)
plt.figure(figsize=(10, 10))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')
plt.show()

word_frequency6 = word_frequency6[word_frequency6["word"].str.contains("new|followback") == False]
data6 = word_frequency6.set_index('word').to_dict()['frequency']
wc = WordCloud(width=800, height=400, max_words=200).generate_from_frequencies(data6)
plt.figure(figsize=(10, 10))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')
plt.show()

#####################################################################################
#####################################################################################
##################################### Ukraine Refugee ###############################
# stop word removal
ukraine_ref['Content'] = ukraine_ref['Content'].astype('str')
ukraine_ref['Location'] = ukraine_ref['Location'].astype('str')

ukraine_ref['clean_content']= ukraine_ref["Content"].str.lower()
ukraine_ref['clean_locs']= ukraine_ref["Location"].str.lower()

english_stop_words = stopwords.words('english')

ukraine_ref['clean_content'] = ukraine_ref['clean_content'].apply(lambda x: ' '.join([word for word in x.split() if word not in (english_stop_words)]))
ukraine_ref['clean_locs'] = ukraine_ref['clean_locs'].apply(lambda x: ' '.join([word for word in x.split() if word not in (english_stop_words)]))

################################# Limmization ########################################

ukraine_ref['clean_content'] = get_lemmatized_text(ukraine_ref['clean_content'])
ukraine_ref['clean_content'] = ukraine_ref['clean_content'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

ukraine_ref['clean_locs'] = get_lemmatized_text(ukraine_ref['clean_locs'])
ukraine_ref['clean_locs'] = ukraine_ref['clean_locs'].str.replace(r'\b\w\b', '').str.replace(r'\s+', ' ')

############################## Tokenize lemmatized comments ############################

ukraine_ref['clean_content'] = ukraine_ref['clean_content'].apply(addwords)
ukraine_ref['clean_locs'] = ukraine_ref['clean_locs'].apply(addwords)

#################### removing unwarrented tags ########################################

c1 = ukraine_ref['clean_content'].tolist()

final_tags = [ [] for i in range(5000) ]

tags = ['FW','JJ','JJR','JJS','MD','NN','NNS','NNP','NNPS','RB','RBR','RBS',
        'SYM','VB','VBD','VBG','VBN']

for i in range(len(c1)):
    #print(i)
    for j in range(len(c1[i])):
        #print(j)
        for k in tags:
            if k == c1[i][j][1]:
                final_tags[i].append(c1[i][j][0])
                continue

ukraine_ref['clean_content'] = final_tags

#
c2 = ukraine_ref['clean_locs'].tolist()

final_tags2 = [ [] for i in range(5000) ]

for i in range(len(c2)):
    #print(i)
    for j in range(len(c2[i])):
        #print(j)
        for k in tags:
            if k == c2[i][j][1]:
                final_tags2[i].append(c2[i][j][0])
                continue

ukraine_ref['clean_locs'] = final_tags2

################### word frequency on Ukraine refugee tweets & location #####################
c3 = list(itertools.chain.from_iterable(ukraine_ref['clean_content']))

counts = Counter(c3)
data_items = counts.items()
data_list = list(data_items)

word_frequency7 = pd.DataFrame(data_list)
word_frequency7.rename(columns = {0:'word', 1:'frequency'}, inplace = True)
word_frequency7 = word_frequency7.sort_values(by = 'frequency', ascending = False)

c4 = list(itertools.chain.from_iterable(ukraine_ref['clean_locs']))

counts = Counter(c4)
data_items = counts.items()
data_list = list(data_items)

word_frequency8 = pd.DataFrame(data_list)
word_frequency8.rename(columns = {0:'word', 1:'frequency'}, inplace = True)
word_frequency8 = word_frequency8.sort_values(by = 'frequency', ascending = False)

#syria_war = syria_war[syria_war['clean_locs'].isin(city)]

#################### Word cloud on Ukraine Refugee tweets #####################
word_frequency7 = word_frequency7[word_frequency7["word"].str.contains("war|amp|new|day|even|dont|first|many|must") == False]
data7 = word_frequency7.set_index('word').to_dict()['frequency']
wc = WordCloud(width=800, height=400, max_words=200).generate_from_frequencies(data7)
plt.figure(figsize=(10, 10))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')
plt.show()

word_frequency8 = word_frequency8[word_frequency8["word"].str.contains("somewhere|new|everywhere|baby|cack|city|free|home|live|die|help") == False]
data8 = word_frequency8.set_index('word').to_dict()['frequency']
wc = WordCloud(width=800, height=400, max_words=200).generate_from_frequencies(data8)
plt.figure(figsize=(10, 10))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')
plt.show()

# writing files on word frequency for,
''' 1. Syria war tweets
    2. Syrai war active location of tweets
    3. Ukraine war tweets
    4. Ukraine war active location of tweets
    5. Syria refugee tweets
    6. Syria active locations for tweets on refugee
    7. Ukraine refugee tweets
    8. Ukraine active locations for tweets on refugee '''


word_frequency.to_csv('syria_war_content.csv', sep=',')
word_frequency2.to_csv('syria_war_loation.csv', sep=',')
word_frequency3.to_csv('ukraine_war_content.csv', sep=',')
word_frequency4.to_csv('ukraine_war_loation.csv', sep=',')
word_frequency5.to_csv('syria_ref_content.csv', sep='\t')
word_frequency6.to_csv('syria_ref_loation.csv', sep='\t')
word_frequency7.to_csv('ukraine_ref_content.csv', sep='\t')
word_frequency8.to_csv('ukraine_ref_location.csv', sep='\t')


###############################################################################
# Plotting active/ favorable locations tweets came from on crisis

import pandas as pd

# Load Syria and Ukraine location data on tweets saves above line 562
# Datasets are flipped with syria and ukraine tweets on locations and same script can be used for generating bar charts
df = pd.read_csv("ukraine_ref_location.csv")

#
from matplotlib import pyplot as plt
 
df = df[df["word"].str.contains("somewhere|alphaville|barueri|et|kyiv|delhi|world|marne|bos|north|seine|maene|new|everywhere|baby|cack|city|free|home|live|die|help|waterloo|ontario|almeria|ukraine|new|hong|kong|dc|york|washington|london|followback|berlin|united|earth|city|paris|state|nyc|kingdom|sea") == False]
name = df['word'].head(10)
price = df['frequency'].head(10)
 
# Figure Size
fig, ax = plt.subplots(figsize =(16, 9))
 
# Horizontal Bar Plot
ax.barh(name, price)

# Remove axes splines
for s in ['top', 'bottom', 'left', 'right']:
    ax.spines[s].set_visible(False)
 
# Remove x, y Ticks
ax.xaxis.set_ticks_position('none')
ax.yaxis.set_ticks_position('none')
 
# Add padding between axes and labels
ax.xaxis.set_tick_params(pad = 5)
ax.yaxis.set_tick_params(pad = 10)
 
# Add x, y gridlines
ax.grid(b = True, color ='grey',
        linestyle ='-.', linewidth = 0.5,
        alpha = 0.2)
 
# Show top values
ax.invert_yaxis()
 
# Add annotation to bars
for i in ax.patches:
    plt.text(i.get_width()+0.2, i.get_y()+0.5,
             str(round((i.get_width()), 2)),
             fontsize = 10, fontweight ='bold',
             color ='grey')
 
# Add Plot Title
ax.set_title('Frequency of words',
             loc ='left', )
 
# Add Text watermark
fig.text(0.9, 0.15, '@author:vaibhav', fontsize = 12,
         color ='grey', ha ='right', va ='bottom',
         alpha = 0.7)
 
# Show Plot
plt.show()

####################################################################################
# Topic Modeling on tweets content on war and refugee crisis of Syria and Ukraine

syria_war['clean_content'] = [' '.join(map(str, l)) for l in syria_war['clean_content']]
ukraine_war['clean_content'] = [' '.join(map(str, l)) for l in ukraine_war['clean_content']]

syria_ref['clean_content'] = [' '.join(map(str, l)) for l in syria_ref['clean_content']]
ukraine_ref['clean_content'] = [' '.join(map(str, l)) for l in ukraine_ref['clean_content']]

###### Syria war tweets content 
 
# the vectorizer object will be used to transform text to vector form
vectorizer = CountVectorizer(max_df=0.9, min_df=25, token_pattern='\w+|\$[\d\.]+|\S+')

# apply transformation
tf = vectorizer.fit_transform(syria_war['clean_content']).toarray()

# tf_feature_names tells us what word each column in the matric represents
tf_feature_names = vectorizer.get_feature_names()

number_of_topics = 6

model = LatentDirichletAllocation(n_components=number_of_topics, random_state=0)

model.fit(tf)

def display_topics(model, feature_names, no_top_words):
    topic_dict = {}
    for topic_idx, topic in enumerate(model.components_):
        topic_dict["Topic %d words" % (topic_idx)]= ['{}'.format(feature_names[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
        topic_dict["Topic %d weights" % (topic_idx)]= ['{:.1f}'.format(topic[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
    return pd.DataFrame(topic_dict)

no_top_words = 6
tm = pd.DataFrame(display_topics(model, tf_feature_names, no_top_words))

##### Ukraine war tweets content

# the vectorizer object will be used to transform text to vector form
vectorizer = CountVectorizer(max_df=0.9, min_df=25, token_pattern='\w+|\$[\d\.]+|\S+')

# apply transformation
tf = vectorizer.fit_transform(ukraine_war['clean_content']).toarray()

# tf_feature_names tells us what word each column in the matric represents
tf_feature_names = vectorizer.get_feature_names()

number_of_topics = 6

model = LatentDirichletAllocation(n_components=number_of_topics, random_state=0)

model.fit(tf)

def display_topics(model, feature_names, no_top_words):
    topic_dict = {}
    for topic_idx, topic in enumerate(model.components_):
        topic_dict["Topic %d words" % (topic_idx)]= ['{}'.format(feature_names[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
        topic_dict["Topic %d weights" % (topic_idx)]= ['{:.1f}'.format(topic[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
    return pd.DataFrame(topic_dict)

no_top_words = 6
tm2 = pd.DataFrame(display_topics(model, tf_feature_names, no_top_words))

###### Syria refugee tweets content

# the vectorizer object will be used to transform text to vector form
vectorizer = CountVectorizer(max_df=0.9, min_df=25, token_pattern='\w+|\$[\d\.]+|\S+')

# apply transformation
tf = vectorizer.fit_transform(syria_ref['clean_content']).toarray()

# tf_feature_names tells us what word each column in the matric represents
tf_feature_names = vectorizer.get_feature_names()

number_of_topics = 6

model = LatentDirichletAllocation(n_components=number_of_topics, random_state=0)

model.fit(tf)

def display_topics(model, feature_names, no_top_words):
    topic_dict = {}
    for topic_idx, topic in enumerate(model.components_):
        topic_dict["Topic %d words" % (topic_idx)]= ['{}'.format(feature_names[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
        topic_dict["Topic %d weights" % (topic_idx)]= ['{:.1f}'.format(topic[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
    return pd.DataFrame(topic_dict)

no_top_words = 6
tm3 = pd.DataFrame(display_topics(model, tf_feature_names, no_top_words))

####### Ukraine refugee tweets content

# the vectorizer object will be used to transform text to vector form
vectorizer = CountVectorizer(max_df=0.9, min_df=25, token_pattern='\w+|\$[\d\.]+|\S+')

# apply transformation
tf = vectorizer.fit_transform(ukraine_ref['clean_content']).toarray()

# tf_feature_names tells us what word each column in the matric represents
tf_feature_names = vectorizer.get_feature_names()

number_of_topics = 6

model = LatentDirichletAllocation(n_components=number_of_topics, random_state=0)

model.fit(tf)

def display_topics(model, feature_names, no_top_words):
    topic_dict = {}
    for topic_idx, topic in enumerate(model.components_):
        topic_dict["Topic %d words" % (topic_idx)]= ['{}'.format(feature_names[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
        topic_dict["Topic %d weights" % (topic_idx)]= ['{:.1f}'.format(topic[i])
                        for i in topic.argsort()[:-no_top_words - 1:-1]]
    return pd.DataFrame(topic_dict)

no_top_words = 6
tm4 = pd.DataFrame(display_topics(model, tf_feature_names, no_top_words))






